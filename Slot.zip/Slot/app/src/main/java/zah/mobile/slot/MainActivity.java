package zah.mobile.slot;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Thread thread1;
    private Thread thread2;
    private Thread thread3;
    private Handler handler;
    private ImageView gambar1;
    private ImageView gambar2;
    private ImageView gambar3;
    private int acak1 = 0;
    private int acak2 = 3;
    private int acak3 = 9;
    private int[] gambarResources = new int[]{
            R.drawable.slot_1, R.drawable.slot_2, R.drawable.slot_3,
            R.drawable.slot_4, R.drawable.slot_5, R.drawable.slot_6,
            R.drawable.slot_7, R.drawable.slot_8, R.drawable.slot_9
    };
    private TextView jackpot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btStartStop).setOnClickListener(this);

        this.gambar1 = (ImageView) findViewById(R.id.gambar1);
        this.gambar2 = (ImageView) findViewById(R.id.gambar2);
        this.gambar3 = (ImageView) findViewById(R.id.gambar3);
        this.jackpot = (TextView) findViewById(R.id.tvJackpot);
        this.handler = new Handler(Looper.getMainLooper());

        // Mulai thread slot
        createThread();
    }

    private void createThread() {
        thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (true) {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                gambar1.setImageResource(gambarResources[acak1]);
                            }
                        });
                        acak1 = (acak1 + 1) % gambarResources.length;
                        Thread.sleep(200);
                    }
                } catch (InterruptedException e) {}
            }
        });

        thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (true) {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                gambar2.setImageResource(gambarResources[acak2]);
                            }
                        });
                        acak2 = (acak2 + 1) % gambarResources.length;
                        Thread.sleep(200);
                    }
                } catch (InterruptedException e) {}
            }
        });

        thread3 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (true) {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                gambar3.setImageResource(gambarResources[acak3]);
                            }
                        });
                        acak3 = (acak3 + 1) % gambarResources.length;
                        Thread.sleep(200);
                    }
                } catch (InterruptedException e) {}
            }
        });
    }

    @Override
    public void onClick(View view) {
        if(this.thread1.isAlive()) {
            this.thread1.interrupt();
        } else if(this.thread2.isAlive()) {
            this.thread2.interrupt();
        } else if(this.thread3.isAlive()) {
            this.thread3.interrupt();
        } else {
            this.createThread();
            this.thread1.start();
            this.thread2.start();
            this.thread3.start();
        }

        if (gambarResources[acak1] == gambarResources[acak2] && gambarResources[acak2] == gambarResources[acak3]) {
            jackpot.setVisibility(View.VISIBLE);
            jackpot.setText("JACKPOT");
        } else {
            jackpot.setVisibility(View.INVISIBLE);
        }
    }
}
